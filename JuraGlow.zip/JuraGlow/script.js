document.addEventListener('DOMContentLoaded', () => {
    // DOM elements
    const dom = {
        body: document.body,
        backgroundOverlay: document.getElementById('background-overlay'),
        blurSlider: document.querySelector('.blur-slider'),
        hours: document.getElementById('time-hours'),
        minutes: document.getElementById('time-minutes'),
        greeting: document.getElementById('greeting'),
        quote: document.getElementById('quote-text'),
        topLeftContainer: document.querySelector('.top-left-container'),
        topCenterContainer: document.querySelector('.top-center-container'),
        topRightContainer: document.querySelector('.top-right-container'),
        searchForm: document.getElementById('search-form'),
        searchInput: document.getElementById('search-input'),
        todoWidget: document.getElementById('todo-widget'),
        todoToggle: document.getElementById('todo-toggle'),
        todoContent: document.getElementById('todo-content'),
        todoForm: document.getElementById('todo-form'),
        todoInput: document.getElementById('todo-input'),
        todoList: document.getElementById('todo-list'),
        linksGrid: document.getElementById('links-grid'),
        addLinkBtn: document.getElementById('add-link-btn'),
        linkModal: document.getElementById('link-modal'),
        closeModalBtn: document.getElementById('close-modal-btn'),
        linkForm: document.getElementById('link-form'),
        linkNameInput: document.getElementById('link-name-input'),
        linkUrlInput: document.getElementById('link-url-input'),
        weatherContainer: document.getElementById('weather-container'),
        weatherMascot: document.getElementById('weather-mascot'),
        weatherTemp: document.getElementById('weather-temp'),
        weatherDesc: document.getElementById('weather-desc'),
        locationDisplay: document.getElementById('location-display'),
        locationText: document.getElementById('location-text'),
        weatherForecast: document.getElementById('weather-forecast'),
        weatherEditBtn: document.getElementById('weather-edit-btn'),
        locationForm: document.getElementById('location-form'),
        locationInput: document.getElementById('location-input'),
        weatherMain: document.querySelector('.weather-main'),
        locationResults: document.getElementById('location-results'),
        bottomLeftContainer: document.querySelector('.bottom-left-container'),
        chillMessage: document.getElementById('chill-message'),
        musicPlayer: document.getElementById('music-player'),
        settingsBtn: document.querySelector('.settings-btn'),
        settingsModal: document.getElementById('settings-modal'),
        settingsCloseBtn: document.getElementById('settings-close-btn'),
        settingsToggles: document.getElementById('settings-toggles'),
        imageControlBtn: document.querySelector('.image-control-btn'),
        imageControlsPopup: document.querySelector('.image-controls-popup'),
        pinImageBtn: document.querySelector('.pin-image-btn'),
        resumeImageBtn: document.querySelector('.resume-image-btn'),
        refreshImageBtn: document.querySelector('.refresh-image-btn'),
    };

    // Validate critical DOM elements
    if (!dom.body) console.error('Body element not found. Check index.html for <body> tag.');
    if (!dom.imageControlBtn) console.error('Image control button not found. Check index.html for .image-control-btn.');
    if (!dom.imageControlsPopup) console.error('Image controls popup not found. Check index.html for .image-controls-popup.');
    if (!dom.blurSlider) console.error('Blur slider not found. Check index.html for .blur-slider.');
    if (!dom.backgroundOverlay) console.error('Background overlay not found. Check index.html for #background-overlay.');

    // Configuration
    const config = {
        unsplashAccessKey: '7y5Ucv9iFWfCgw0KrkUd2iLVcoCVy2TWu46CxBMm-lw',
        unsplashCollectionId: '96625331', // Night collection
        imagePoolSize: 10,
        maxLinks: 12,
        weatherCacheDuration: 30 * 60 * 1000, // 30 minutes
        wittyMessages: {
            0: { // Clear sky
                morning: "Sun's up, sky's clear. Time to shine!",
                afternoon: "Blue skies all day. Keep it bright!",
                evening: "Clear evening sky. Stars are warming up!",
                night: "Starlit sky. The night is yours!"
            },
            1: { // Mainly clear
                morning: "Mostly clear, sun's peeking through!",
                afternoon: "Sun's winning, clouds are losing.",
                evening: "Clearish skies, perfect for a sunset.",
                night: "Stars are out, with a few shy clouds."
            },
            2: { // Partly cloudy
                morning: "Clouds flirting with the morning sun.",
                afternoon: "Sun and clouds playing hide-and-seek.",
                evening: "Clouds setting the mood for dusk.",
                night: "Moon's dodging some clouds tonight."
            },
            3: { // Overcast
                morning: "Sky's in a grumpy morning mood.",
                afternoon: "Clouds took over. Sun's on a break.",
                evening: "Overcast vibes, cozy evening ahead.",
                night: "Clouds are hogging the night sky."
            },
            45: { // Foggy
                morning: "Morning fog. Where's the world at?",
                afternoon: "Fog's chilling like a lazy afternoon.",
                evening: "Evening mist. Spooky vibes incoming.",
                night: "Fog's out, like a ninja in the night."
            },
            48: { // Rime fog
                morning: "Frosty fog making a sparkly morning.",
                afternoon: "Rime fog's giving a frosty glow.",
                evening: "Glittery fog for a magical evening.",
                night: "Night's sparkling with rime fog."
            },
            51: { // Light drizzle
                morning: "Morning drizzle, sky's just teasing.",
                afternoon: "Light rain, like the sky's sweating.",
                evening: "Gentle drizzle for a chill evening.",
                night: "Night's got a soft, drizzly vibe."
            },
            61: { // Slight rain
                morning: "Morning shower, nature's wake-up call.",
                afternoon: "Slight rain, perfect for a cozy day.",
                evening: "Light rain for a moody evening.",
                night: "Rain's whispering in the night."
            },
            63: { // Moderate rain
                morning: "Rainy morning. Grab that umbrella!",
                afternoon: "Sky's having a proper rinse.",
                evening: "Rain's setting a dramatic evening tone.",
                night: "Night's getting a solid rinse."
            },
            65: { // Heavy rain
                morning: "Heavy rain. Morning's all wet!",
                afternoon: "Sky's throwing a tantrum today.",
                evening: "Pouring rain, perfect for cozy nights.",
                night: "Night's drowning in epic rain."
            },
            71: { // Slight snow
                morning: "Morning snowflakes, winter's saying hi.",
                afternoon: "Light snow, like sky dandruff.",
                evening: "Snow dusting the evening. So pretty!",
                night: "Night's got a sprinkle of snow."
            },
            75: { // Heavy snow
                morning: "Snowpocalypse morning! Bundle up!",
                afternoon: "Heavy snow, world's a snow globe.",
                evening: "Snow's piling up for a cozy night.",
                night: "Night's a winter wonderland."
            },
            95: { // Thunderstorm
                morning: "Thunder's rocking the morning!",
                afternoon: "Storm's stealing the show today.",
                evening: "Thunderstorm's got evening drama.",
                night: "Night's alive with thunder vibes."
            }
        },
        defaultLinks: [
            { name: "YouTube", url: "https://www.youtube.com" },
            { name: "Facebook", url: "https://www.facebook.com" },
            { name: "Amazon", url: "https://www.amazon.com" },
            { name: "Instagram", url: "https://www.instagram.com" },
            { name: "Wikipedia", url: "https://www.wikipedia.org" }
        ],
        chillMessages: [
            "Chill vibes only.",
            "Time to relax and unwind.",
            "Let the lofi beats carry you away.",
            "Perfect for studying or just chilling.",
            "Enjoy the lofi groove.",
            "Music to soothe your soul.",
            "Take a break and vibe.",
            "Lofi for the win.",
            "Stay calm and listen on.",
            "Your daily dose of chill."
        ],
        defaultLocation: { lat: 40.7128, lon: -74.0060, city: "New York" }
    };

    // State
    const state = {
        todos: [],
        links: [],
        debounceTimer: null,
        player: null,
        visibilitySettings: {}
    };

    // Utility Functions
    function loadStateFromStorage() {
        try {
            state.todos = JSON.parse(localStorage.getItem('todos')) || [];
            console.log('Loaded todos:', state.todos);
            state.links = JSON.parse(localStorage.getItem('links')) || config.defaultLinks;
            console.log('Loaded links:', state.links);
            
            const savedBlur = localStorage.getItem('backgroundBlur') || '5';
            if (dom.blurSlider && dom.backgroundOverlay) {
                dom.blurSlider.value = savedBlur;
                dom.backgroundOverlay.style.setProperty('--background-blur', `${savedBlur}px`);
                dom.backgroundOverlay.style.backdropFilter = `blur(${savedBlur}px)`;
                dom.backgroundOverlay.style.webkitBackdropFilter = `blur(${savedBlur}px)`;
                console.log(`Loaded blur value: ${savedBlur}px`);
            } else {
                console.error('Cannot load blur: blurSlider or backgroundOverlay missing');
            }

            state.visibilitySettings = JSON.parse(localStorage.getItem('visibilitySettings')) || {
                clock: true,
                music: true,
                links: true,
                todo: true,
                search: true,
                weather: true,
                quote: true
            };
            console.log('Loaded visibility settings:', state.visibilitySettings);
        } catch (error) {
            console.error('Failed to load state from storage:', error);
            state.todos = [];
            state.links = config.defaultLinks;
            if (dom.blurSlider && dom.backgroundOverlay) {
                dom.blurSlider.value = '5';
                dom.backgroundOverlay.style.setProperty('--background-blur', '5px');
                dom.backgroundOverlay.style.backdropFilter = `blur(5px)`;
                dom.backgroundOverlay.style.webkitBackdropFilter = `blur(5px)`;
                localStorage.setItem('backgroundBlur', '5');
                console.log('Set default blur value: 5px due to error');
            } else {
                console.error('Cannot set default blur: blurSlider or backgroundOverlay missing');
            }
            state.visibilitySettings = {
                clock: true,
                music: true,
                links: true,
                todo: true,
                search: true,
                weather: true,
                quote: true
            };
        }
        renderTodos();
        renderLinks();
        applyVisibilitySettings();
    }

    function saveTodos() {
        try {
            localStorage.setItem('todos', JSON.stringify(state.todos));
            console.log('Saved todos:', state.todos);
        } catch (error) {
            console.error('Failed to save todos:', error);
        }
    }

    function saveLinks() {
        try {
            localStorage.setItem('links', JSON.stringify(state.links));
            console.log('Saved links:', state.links);
        } catch (error) {
            console.error('Failed to save links:', error);
        }
    }

    function saveVisibilitySettings() {
        try {
            localStorage.setItem('visibilitySettings', JSON.stringify(state.visibilitySettings));
            console.log('Saved visibility settings:', state.visibilitySettings);
        } catch (error) {
            console.error('Failed to save visibility settings:', error);
        }
    }

    function applyVisibilitySettings() {
        const featureMap = {
            clock: dom.topLeftContainer,
            music: dom.topCenterContainer,
            links: dom.topRightContainer,
            todo: dom.todoWidget,
            search: dom.searchForm,
            weather: dom.weatherContainer,
            quote: dom.bottomLeftContainer
        };

        for (const feature in state.visibilitySettings) {
            const isVisible = state.visibilitySettings[feature];
            const element = featureMap[feature];
            if (element) {
                element.classList.toggle('hidden', !isVisible);
            }
            if (dom.settingsToggles) {
                const checkbox = dom.settingsToggles.querySelector(`[data-feature="${feature}"]`);
                if (checkbox) {
                    checkbox.checked = isVisible;
                }
            }
        }
    }

    function updateImageControlsUI() {
        if (dom.pinImageBtn && dom.resumeImageBtn && dom.refreshImageBtn) {
            const isPinned = !!localStorage.getItem('pinnedImageUrl');
            dom.pinImageBtn.classList.toggle('hidden', isPinned);
            dom.resumeImageBtn.classList.toggle('hidden', !isPinned);
            dom.refreshImageBtn.disabled = isPinned;
            console.log('Updated image controls UI', {
                isPinned,
                pinnedImageUrl: localStorage.getItem('pinnedImageUrl'),
                currentBackgroundImage: localStorage.getItem('currentBackgroundImage'),
                imagePoolSize: (JSON.parse(localStorage.getItem('imagePool')) || []).length
            });
        }
    }

    function handleVisibilityToggle(e) {
        if (e.target.matches('input[type="checkbox"]')) {
            const feature = e.target.dataset.feature;
            const isVisible = e.target.checked;
            state.visibilitySettings[feature] = isVisible;
            saveVisibilitySettings();
            applyVisibilitySettings();
        }
    }

    function debounce(func, delay) {
        return function (...args) {
            clearTimeout(state.debounceTimer);
            state.debounceTimer = setTimeout(() => {
                func.apply(this, args);
            }, delay);
        };
    }

    // Clock and Greeting
    function updateClock() {
        try {
            if (!dom.hours || !dom.minutes) throw new Error('Clock elements missing');
            const now = new Date();
            const hours = now.getHours();
            let minutes = now.getMinutes();
            let displayHours = hours % 12 || 12;
            minutes = minutes < 10 ? '0' + minutes : minutes;
            dom.hours.textContent = displayHours;
            dom.minutes.textContent = minutes;
            console.log('Updated clock:', `${displayHours}:${minutes}`);
        } catch (error) {
            console.error('Failed to update clock:', error);
            if (dom.hours) dom.hours.textContent = '--';
            if (dom.minutes) dom.minutes.textContent = '--';
        }
    }

    function setGreeting() {
        try {
            if (!dom.greeting || !dom.topLeftContainer) throw new Error('Greeting elements missing');
            const now = new Date();
            const hours = now.getHours();
            const GREETING_PARTS = {
                prefix: {
                    earlyMorning: ["It's way too early, but", "While the world sleeps", "The sun is barely up. Anyway"],
                    morning: ["Time for that second coffee.", "Looks like a productive morning.", "The day is in full swing."],
                    afternoon: ["Hope you had a good lunch.", "The afternoon awaits.", "Peak productivity time... maybe."],
                    evening: ["Time to wind down.", "The day is almost done.", "Hope your evening is relaxing."],
                    lateNight: ["Burning the midnight oil, I see.", "Hello, fellow night owl.", "The moon is out."]
                },
                suffix: ["let's do the thing.", "go get 'em, tiger.", "don't forget to be awesome.", "the simulation is running smoothly.", "time to make some magic happen."]
            };
            let prefixPool;
            if (hours >= 5 && hours < 8) prefixPool = GREETING_PARTS.prefix.earlyMorning;
            else if (hours >= 8 && hours < 12) prefixPool = GREETING_PARTS.prefix.morning;
            else if (hours >= 12 && hours < 17) prefixPool = GREETING_PARTS.prefix.afternoon;
            else if (hours >= 17 && hours < 22) prefixPool = GREETING_PARTS.prefix.evening;
            else prefixPool = GREETING_PARTS.prefix.lateNight;
            const prefix = prefixPool[Math.floor(Math.random() * prefixPool.length)];
            const suffix = GREETING_PARTS.suffix[Math.floor(Math.random() * GREETING_PARTS.suffix.length)];
            dom.greeting.textContent = `${prefix} ${suffix}`;
            dom.topLeftContainer.classList.remove('is-morning', 'is-afternoon', 'is-evening');
            if (hours < 12) dom.topLeftContainer.classList.add('is-morning');
            else if (hours < 18) dom.topLeftContainer.classList.add('is-afternoon');
            else dom.topLeftContainer.classList.add('is-evening');
            console.log('Set greeting:', dom.greeting.textContent);
        } catch (error) {
            console.error('Failed to set greeting:', error);
            if (dom.greeting) dom.greeting.textContent = 'Hello, world!';
        }
    }

    // Background Image
    async function setBackground(caller = 'unknown') {
        try {
            if (!dom.body) throw new Error('Body element not found');
            console.log(`Setting background (caller: ${caller})`);
            dom.body.classList.add('no-transition');
            const pinnedImageUrl = localStorage.getItem('pinnedImageUrl');
            if (pinnedImageUrl && pinnedImageUrl.startsWith('http')) {
                dom.body.style.backgroundImage = `url(${pinnedImageUrl})`;
                console.log(`Set background to pinned image: ${pinnedImageUrl}`);
                dom.body.classList.remove('no-transition');
                updateImageControlsUI();
                return;
            }
            let imagePool = JSON.parse(localStorage.getItem('imagePool')) || [];
            if (imagePool.length === 0) {
                console.log('Image pool empty, refilling...');
                await refillImagePool();
                imagePool = JSON.parse(localStorage.getItem('imagePool')) || [];
            }
            if (imagePool.length === 0) {
                console.warn('Image pool still empty after refill, using fallback');
                const fallbackUrl = 'https://images.unsplash.com/photo-1514565131-fce0801e5785';
                dom.body.style.backgroundImage = `url(${fallbackUrl})`;
                localStorage.setItem('currentBackgroundImage', fallbackUrl);
                console.log(`Set fallback image: ${fallbackUrl}`);
            } else {
                // Shuffle image pool for randomization
                imagePool = shuffleArray(imagePool);
                const nextImageUrl = imagePool.shift();
                localStorage.setItem('currentBackgroundImage', nextImageUrl);
                localStorage.setItem('imagePool', JSON.stringify(imagePool));
                dom.body.style.backgroundImage = `url(${nextImageUrl})`;
                console.log(`Set background image: ${nextImageUrl}, remaining pool size: ${imagePool.length}`);
            }
            dom.body.classList.remove('no-transition');
            updateImageControlsUI();
        } catch (error) {
            console.error(`Failed to set background (caller: ${caller}):`, error);
            if (dom.body) {
                const fallbackUrl = 'https://images.unsplash.com/photo-1514565131-fce0801e5785';
                dom.body.style.backgroundImage = `url(${fallbackUrl})`;
                localStorage.setItem('currentBackgroundImage', fallbackUrl);
                console.log(`Set fallback image: ${fallbackUrl}`);
                dom.body.classList.remove('no-transition');
                updateImageControlsUI();
            }
        }
    }

    // Utility function to shuffle an array
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    async function refillImagePool() {
        console.log('refillImagePool called');
        const maxRetries = 3;
        let attempt = 1;

        while (attempt <= maxRetries) {
            try {
                if (!config.unsplashAccessKey || !config.unsplashCollectionId) {
                    console.error('Missing Unsplash API key or collection ID');
                    throw new Error('Missing Unsplash API key or collection ID');
                }
                // Fetch collection info to get total photos
                const collectionInfoUrl = `https://api.unsplash.com/collections/${config.unsplashCollectionId}?client_id=${config.unsplashAccessKey}`;
                const infoResponse = await fetch(collectionInfoUrl, {
                    headers: { 'Accept-Version': 'v1' }
                });
                if (!infoResponse.ok) {
                    const errorText = await infoResponse.text();
                    console.error(`Unsplash collection info response (attempt ${attempt}):`, infoResponse.status, infoResponse.statusText, 'Response body:', errorText);
                    throw new Error(`Unsplash collection info error: ${infoResponse.status}`);
                }
                const collectionInfo = await infoResponse.json();
                const totalPhotos = collectionInfo.total_photos || 500; // Fallback to 500 if API doesn't provide total
                const maxPages = Math.ceil(totalPhotos / config.imagePoolSize);
                const randomPage = Math.floor(Math.random() * maxPages) + 1;

                // Fetch images from a random page
                const url = `https://api.unsplash.com/collections/${config.unsplashCollectionId}/photos?client_id=${config.unsplashAccessKey}&per_page=${config.imagePoolSize}&page=${randomPage}`;
                console.log(`Attempt ${attempt}: Fetching ${config.imagePoolSize} images from collection ${config.unsplashCollectionId}, page ${randomPage}`);
                const response = await fetch(url, {
                    headers: { 'Accept-Version': 'v1' }
                });
                console.log('Response status:', response.status, response.statusText);
                if (!response.ok) {
                    const errorText = await response.text();
                    console.error(`Unsplash API response (attempt ${attempt}):`, response.status, response.statusText, 'Response body:', errorText);
                    throw new Error(`Unsplash API error: ${response.status}`);
                }
                const data = await response.json();
                console.log('Received API response:', data);
                const imageUrls = Array.isArray(data) ? data.map(photo => `${photo.urls.raw}&w=1920&q=80&fm=jpg`) : [];
                if (imageUrls.length === 0) {
                    console.error('No images returned from Unsplash collection');
                    throw new Error('No images returned from Unsplash collection');
                }
                // Shuffle the fetched images for additional randomization
                const shuffledUrls = shuffleArray(imageUrls);
                localStorage.setItem('imagePool', JSON.stringify(shuffledUrls));
                console.log('Image pool updated with', shuffledUrls.length, 'images from collection', config.unsplashCollectionId, 'page', randomPage);
                return;
            } catch (error) {
                console.error(`Failed to refill image pool (attempt ${attempt}):`, error.message);
                attempt++;
                if (attempt > maxRetries) {
                    console.error('Max retries reached, setting fallback image');
                    const fallbackUrl = 'https://images.unsplash.com/photo-1514565131-fce0801e5785';
                    localStorage.setItem('imagePool', JSON.stringify([fallbackUrl]));
                    return;
                }
                console.log(`Retrying (${attempt}/${maxRetries})...`);
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
        }
    }

    async function prepareNextBackground(forceSet = false, caller = 'unknown') {
        try {
            if (!dom.body) throw new Error('Body element not found');
            console.log(`Preparing next background (caller: ${caller}, forceSet: ${forceSet})`);
            const pinnedImageUrl = localStorage.getItem('pinnedImageUrl');
            if (pinnedImageUrl && pinnedImageUrl.startsWith('http')) {
                console.log(`Pinned image active: ${pinnedImageUrl}, skipping preparation`);
                if (forceSet) await setBackground(caller);
                return;
            }
            let imagePool = JSON.parse(localStorage.getItem('imagePool')) || [];
            console.log('Current image pool:', imagePool);
            if (imagePool.length <= 2) { // Refill when pool is low
                console.log('Image pool low or empty, refilling...');
                await refillImagePool();
                imagePool = JSON.parse(localStorage.getItem('imagePool')) || [];
                console.log('Image pool refilled:', imagePool);
            }
            if (imagePool.length === 0) {
                console.error('Image pool empty after refill, using fallback');
                const fallbackUrl = 'https://images.unsplash.com/photo-1514565131-fce0801e5785';
                localStorage.setItem('currentBackgroundImage', fallbackUrl);
                localStorage.setItem('imagePool', JSON.stringify([]));
                if (forceSet) await setBackground(caller);
            } else {
                // Shuffle pool for randomization
                imagePool = shuffleArray(imagePool);
                const nextImageUrl = imagePool.shift();
                localStorage.setItem('currentBackgroundImage', nextImageUrl);
                localStorage.setItem('imagePool', JSON.stringify(imagePool));
                console.log(`Prepared next background image: ${nextImageUrl}, remaining pool size: ${imagePool.length}`);
                if (forceSet) await setBackground(caller);
            }
        } catch (error) {
            console.error(`Failed to prepare next background (caller: ${caller}):`, error);
            const fallbackUrl = 'https://images.unsplash.com/photo-1514565131-fce0801e5785';
            localStorage.setItem('currentBackgroundImage', fallbackUrl);
            localStorage.setItem('imagePool', JSON.stringify([]));
            if (forceSet) await setBackground(caller);
        }
    }

    // Quote
    async function setQuote() {
        try {
            if (!dom.quote) throw new Error('Quote element missing');
            const response = await fetch('https://icanhazdadjoke.com/', {
                headers: { 'Accept': 'application/json' }
            });
            if (!response.ok) throw new Error('Joke API error');
            const data = await response.json();
            dom.quote.textContent = `"${data.joke}"`;
            console.log('Set quote:', data.joke);
        } catch (error) {
            console.error('Failed to set quote:', error);
            if (dom.quote) dom.quote.textContent = '"Keep calm and carry on!"';
        }
    }

    // To-Do List
    function renderTodos() {
        try {
            if (!dom.todoList) throw new Error('Todo list element missing');
            dom.todoList.innerHTML = '';
            state.todos.forEach((todo, index) => {
                const li = document.createElement('li');
                li.className = `todo-item ${todo.completed ? 'completed' : ''}`;
                li.setAttribute('data-index', index);
                li.innerHTML = `
                    <button class="todo-edit-btn">✎</button>
                    <input type="checkbox" ${todo.completed ? 'checked' : ''}>
                    <span>${todo.text}</span>
                    <button class="todo-delete-btn">×</button>
                `;
                dom.todoList.appendChild(li);
            });

            if (state.todos.length > 0) {
                dom.todoContent.classList.remove('hidden');
            } else {
                dom.todoContent.classList.add('hidden');
            }

            console.log('Rendered todos:', state.todos);
        } catch (error) {
            console.error('Failed to render todos:', error);
        }
    }

    function addTodo(text) {
        try {
            if (text.trim()) {
                state.todos.push({ text: text.trim(), completed: false });
                saveTodos();
                renderTodos();
                console.log('Added todo:', text);
            }
        } catch (error) {
            console.error('Failed to add todo:', error);
        }
    }

    function toggleTodo(index) {
        try {
            state.todos[index].completed = !state.todos[index].completed;
            saveTodos();
            renderTodos();
            console.log('Toggled todo at index:', index);
        } catch (error) {
            console.error('Failed to toggle todo:', error);
        }
    }

    function deleteTodo(index) {
        try {
            state.todos.splice(index, 1);
            saveTodos();
            renderTodos();
            console.log('Deleted todo at index:', index);
        } catch (error) {
            console.error('Failed to delete todo:', error);
        }
    }

    // Quick Links
    function renderLinks() {
        try {
            if (!dom.linksGrid) throw new Error('Links grid element missing');
            dom.linksGrid.innerHTML = '';
            state.links.forEach((link, index) => {
                const linkAnchor = document.createElement('a');
                linkAnchor.href = link.url;
                linkAnchor.className = 'link-item';
                const faviconUrl = `https://www.google.com/s2/favicons?domain=${link.url}&sz=32`;
                linkAnchor.innerHTML = `
                    <div class="link-icon-circle">
                        <img src="${faviconUrl}" class="link-favicon" alt="${link.name}">
                    </div>
                    <span class="link-name">${link.name}</span>
                    <button class="delete-link-btn" data-index="${index}">×</button>
                `;
                dom.linksGrid.appendChild(linkAnchor);
            });
            if (dom.addLinkBtn) {
                dom.addLinkBtn.classList.toggle('hidden', state.links.length >= config.maxLinks);
            }
            console.log('Rendered links:', state.links);
        } catch (error) {
            console.error('Failed to render links:', error);
        }
    }

    function addLink(name, url) {
        try {
            if (name.trim() && url.trim() && state.links.length < config.maxLinks) {
                const formattedUrl = url.startsWith('http') ? url : `https://${url}`;
                state.links.push({ name: name.trim(), url: formattedUrl });
                saveLinks();
                renderLinks();
                console.log('Added link:', { name, url: formattedUrl });
            }
        } catch (error) {
            console.error('Failed to add link:', error);
        }
    }

    function deleteLink(index) {
        try {
            state.links.splice(index, 1);
            saveLinks();
            renderLinks();
            console.log('Deleted link at index:', index);
        } catch (error) {
            console.error('Failed to delete link:', error);
        }
    }

    // Weather
    function getWeatherMascot(code) {
        try {
            const svgSun = `
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="5"></circle>
                    <line x1="12" y1="1" x2="12" y2="3"></line>
                    <line x1="12" y1="21" x2="12" y2="23"></line>
                    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                    <line x1="1" y1="12" x2="3" y2="12"></line>
                    <line x1="21" y1="12" x2="23" y2="12"></line>
                    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                </svg>`;
            const svgCloud = `
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"></path>
                </svg>`;
            const svgRain = `
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path d="M20 16.58A5 5 0 0 0 18 7h-1.26A8 8 0 1 0 4 15.25"></path>
                    <line x1="8" y1="22" x2="8" y2="22" stroke-width="3" stroke-linecap="round"></line>
                    <line x1="12" y1="22" x2="12" y2="22" stroke-width="3" stroke-linecap="round"></line>
                    <line x1="16" y1="22" x2="16" y2="22" stroke-width="3" stroke-linecap="round"></line>
                </svg>`;
            switch (code) {
                case 0:
                case 1:
                    return svgSun;
                case 2:
                case 3:
                case 45:
                case 48:
                    return svgCloud;
                case 51:
                case 61:
                case 63:
                case 65:
                case 95:
                    return svgRain;
                default:
                    return svgCloud;
            }
        } catch (error) {
            console.error('Failed to get weather mascot:', error);
            return '';
        }
    }

    function getTimeOfDay() {
        const hours = new Date().getHours();
        if (hours >= 5 && hours < 12) return 'morning';
        else if (hours >= 12 && hours < 17) return 'afternoon';
        else if (hours >= 17 && hours < 22) return 'evening';
        else return 'night';
    }

    function renderWeather(data, city) {
    try {
        if (!dom.weatherTemp || !dom.weatherDesc || !dom.locationText || !dom.weatherMascot || !dom.weatherForecast)
            throw new Error('Weather elements missing');
        const code = data.current_weather.weathercode;
        const timeOfDay = getTimeOfDay();
        const messages = config.wittyMessages[code] || {
            morning: "Weather's being weird today.",
            afternoon: "Sky's up to something strange.",
            evening: "Evening's got odd weather vibes.",
            night: "Night's weather is a mystery."
        };
        dom.weatherTemp.textContent = `${Math.round(data.current_weather.temperature)}°`;
        dom.weatherDesc.textContent = messages[timeOfDay];
        dom.locationText.textContent = city;
        dom.weatherMascot.innerHTML = getWeatherMascot(code);
        dom.weatherForecast.innerHTML = '';
        for (let i = 0; i < 7; i++) {
            const day = document.createElement('div');
            day.className = 'forecast-day';
            const dayName = i === 0 ? "Today" : new Date(data.daily.time[i]).toLocaleDateString('en-US', { weekday: 'short' });
            day.innerHTML = `
                <span class="forecast-day-name">${dayName}</span>
                <span class="forecast-day-temp">${Math.round(data.daily.temperature_2m_min[i])}° / ${Math.round(data.daily.temperature_2m_max[i])}°</span>
            `;
            dom.weatherForecast.appendChild(day);
        }
        // Only show the weather container if the weather feature is enabled
        if (state.visibilitySettings.weather && dom.weatherContainer) {
            dom.weatherContainer.classList.remove('hidden');
        }
        console.log('Rendered weather for:', city, 'with message:', messages[timeOfDay]);
    } catch (error) {
        console.error('Failed to render weather:', error);
        // Only show the weather container if the weather feature is enabled
        if (state.visibilitySettings.weather && dom.weatherContainer) {
            dom.weatherContainer.classList.remove('hidden');
        }
        if (dom.weatherDesc) dom.weatherDesc.textContent = 'Weather unavailable, try another location';
        if (dom.locationText) dom.locationText.textContent = city || 'Unknown';
    }
}

    async function fetchWeather(lat, lon, city) {
        try {
            if (typeof lat !== 'number' || typeof lon !== 'number' || isNaN(lat) || isNaN(lon)) {
                throw new Error(`Invalid coordinates: lat=${lat}, lon=${lon}`);
            }
            const weatherCache = JSON.parse(localStorage.getItem('weatherCache'));
            if (weatherCache && weatherCache.city === city && (Date.now() - weatherCache.timestamp < config.weatherCacheDuration)) {
                console.log('Using cached weather data for:', city);
                renderWeather(weatherCache.data, city);
                return;
            }
            const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&daily=weathercode,temperature_2m_max,temperature_2m_min&current_weather=true&timezone=auto&forecast_days=7`;
            console.log('Fetching weather from URL:', url);
            const response = await fetch(url);
            if (!response.ok) {
                const errorText = await response.text();
                console.error(`Weather API response error: ${response.status} ${response.statusText}, Response body:`, errorText);
                throw new Error(`Weather API error: ${response.status}`);
            }
            const data = await response.json();
            localStorage.setItem('weatherCache', JSON.stringify({ data, city, timestamp: Date.now() }));
            console.log('Fetched and cached weather for:', city);
            renderWeather(data, city);
        } catch (error) {
            console.error('Failed to fetch weather:', error);
            if (dom.weatherContainer) dom.weatherContainer.classList.remove('hidden');
            if (dom.weatherDesc) dom.weatherDesc.textContent = 'Weather data unavailable, please try again later';
            if (dom.locationText) dom.locationText.textContent = city || 'Unknown';
        }
    }

    async function getCoordsForCity(city, setAsCurrent = false) {
        try {
            const response = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=5&language=en&format=json`);
            if (!response.ok) throw new Error(`Geocoding API error: ${response.status}`);
            const data = await response.json();
            if (!data.results || data.results.length === 0) {
                console.log('No geocoding results for:', city);
                renderLocationResults([]);
                return;
            }
            if (setAsCurrent) {
                const location = data.results[0];
                const settings = { lat: location.latitude, lon: location.longitude, city: location.name };
                localStorage.setItem('weatherSettings', JSON.stringify(settings));
                console.log('Saved weather settings:', settings);
                await fetchWeather(location.latitude, location.longitude, location.name);
            } else {
                renderLocationResults(data.results);
            }
        } catch (error) {
            console.error('Failed to get coordinates for city:', error);
            renderLocationResults([]);
        }
    }

    function renderLocationResults(results) {
        try {
            if (!dom.locationResults) throw new Error('Location results element missing');
            dom.locationResults.innerHTML = '';
            if (results.length === 0) {
                dom.locationResults.classList.add('hidden');
                return;
            }
            results.forEach(location => {
                const item = document.createElement('div');
                item.className = 'location-result-item';
                item.textContent = `${location.name}, ${location.admin1 || ''} ${location.country_code || ''}`.trim().replace(/, $/, '');
                item.addEventListener('click', () => {
                    const settings = { lat: location.latitude, lon: location.longitude, city: location.name };
                    localStorage.setItem('weatherSettings', JSON.stringify(settings));
                    console.log('Selected location:', settings);
                    fetchWeather(location.latitude, location.longitude, location.name);
                    if (dom.locationInput) dom.locationInput.value = '';
                    if (dom.locationResults) dom.locationResults.classList.add('hidden');
                    if (dom.locationForm) dom.locationForm.classList.add('hidden');
                });
                dom.locationResults.appendChild(item);
            });
            dom.locationResults.classList.remove('hidden');
            console.log('Rendered location results:', results);
        } catch (error) {
            console.error('Failed to render location results:', error);
            if (dom.locationResults) dom.locationResults.classList.add('hidden');
        }
    }

    async function handleLocation() {
        try {
            let savedSettings = JSON.parse(localStorage.getItem('weatherSettings'));
            if (savedSettings && savedSettings.lat && savedSettings.lon && savedSettings.city) {
                console.log('Using saved weather settings:', savedSettings);
                await fetchWeather(savedSettings.lat, savedSettings.lon, savedSettings.city);
            } else {
                try {
                    const response = await fetch('https://get.geojs.io/v1/ip/geo.json');
                    if (!response.ok) throw new Error(`GeoJS API error: ${response.status}`);
                    const data = await response.json();
                    const settings = {
                        lat: parseFloat(data.latitude),
                        lon: parseFloat(data.longitude),
                        city: data.city || 'Unknown'
                    };
                    if (isNaN(settings.lat) || isNaN(settings.lon)) {
                        throw new Error('Invalid GeoJS coordinates');
                    }
                    localStorage.setItem('weatherSettings', JSON.stringify(settings));
                    console.log('Saved GeoJS location:', settings);
                    await fetchWeather(settings.lat, settings.lon, settings.city);
                } catch (error) {
                    console.error('Failed to get GeoJS location:', error);
                    console.log('Falling back to default location:', config.defaultLocation);
                    await fetchWeather(config.defaultLocation.lat, config.defaultLocation.lon, config.defaultLocation.city);
                }
            }
        } catch (error) {
            console.error('Failed to handle location:', error);
            console.log('Falling back to default location:', config.defaultLocation);
            await fetchWeather(config.defaultLocation.lat, config.defaultLocation.lon, config.defaultLocation.city);
        }
    }

    // Music Player
    function loadYouTubeIframeAPI() {
    try {
        const tag = document.createElement('script');
        tag.src = 'scripts/youtube-iframe-api.js'; // Path to local script
        const firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
        console.log('Loaded local YouTube Iframe API script');
    } catch (error) {
        console.error('Failed to load local YouTube Iframe API:', error);
        if (dom.chillMessage) dom.chillMessage.textContent = 'Music player unavailable';
    }
}

    window.onYouTubeIframeAPIReady = function () {
        try {
            state.player = new YT.Player('music-player', {
                events: {
                    'onReady': () => {
                        console.log('YouTube player ready');
                        state.player.playVideo();
                    },
                    'onError': (error) => {
                        console.error('YouTube player error:', error);
                        if (dom.chillMessage) dom.chillMessage.textContent = 'Music player error';
                    }
                }
            });
        } catch (error) {
            console.error('Failed to initialize YouTube player:', error);
            if (dom.chillMessage) dom.chillMessage.textContent = 'Music player unavailable';
        }
    };

    function setChillMessage() {
        try {
            if (!dom.chillMessage) throw new Error('Chill message element missing');
            const message = config.chillMessages[Math.floor(Math.random() * config.chillMessages.length)];
            dom.chillMessage.textContent = message;
            console.log('Set chill message:', message);
        } catch (error) {
            console.error('Failed to set chill message:', error);
            if (dom.chillMessage) dom.chillMessage.textContent = 'Chill vibes unavailable';
        }
    }

    // Event Listeners
    function setupEventListeners() {
        try {
            console.log('Setting up event listeners...');

            // Search
            if (dom.searchForm) {
                dom.searchForm.addEventListener('submit', (e) => {
                    e.preventDefault();
                    const query = dom.searchInput.value.trim();
                    if (query) {
                        window.location.href = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
                        console.log('Search submitted:', query);
                    }
                });
            }

            // To-Do List
            if (dom.todoToggle) {
                dom.todoToggle.addEventListener('click', (e) => {
                    e.preventDefault();
                    if (dom.todoContent) {
                        dom.todoContent.classList.toggle('hidden');
                        console.log('Toggled todo content visibility');
                    }
                });
            }

            if (dom.todoForm) {
                dom.todoForm.addEventListener('submit', (e) => {
                    e.preventDefault();
                    const text = dom.todoInput.value.trim();
                    if (text) {
                        addTodo(text);
                        dom.todoInput.value = '';
                    }
                });
            }

            if (dom.todoList) {
                dom.todoList.addEventListener('click', (e) => {
                    const todoItem = e.target.closest('.todo-item');
                    if (!todoItem) return;

                    const index = parseInt(todoItem.dataset.index);

                    if (e.target.classList.contains('todo-edit-btn')) {
                        const span = todoItem.querySelector('span');
                        const currentText = state.todos[index].text;

                        const input = document.createElement('input');
                        input.type = 'text';
                        input.value = currentText;
                        input.className = 'todo-edit-input';

                        const saveChanges = () => {
                            const newText = input.value.trim();
                            if (newText) {
                                state.todos[index].text = newText;
                                saveTodos();
                            }
                            renderTodos();
                        };

                        input.addEventListener('blur', saveChanges);
                        input.addEventListener('keydown', (e) => {
                            if (e.key === 'Enter') {
                                saveChanges();
                            } else if (e.key === 'Escape') {
                                renderTodos();
                            }
                        });

                        span.replaceWith(input);
                        input.focus();
                        input.setSelectionRange(currentText.length, currentText.length);
                    } else if (e.target.classList.contains('todo-delete-btn')) {
                        deleteTodo(index);
                    } else if (e.target.type === 'checkbox') {
                        toggleTodo(index);
                    }
                });
            }

            // Quick Links
            if (dom.addLinkBtn) {
                dom.addLinkBtn.addEventListener('click', () => {
                    if (dom.linkModal) {
                        dom.linkModal.classList.remove('hidden');
                        console.log('Opened link modal');
                    }
                });
            }

            if (dom.closeModalBtn) {
                dom.closeModalBtn.addEventListener('click', () => {
                    if (dom.linkModal) {
                        dom.linkModal.classList.add('hidden');
                        console.log('Closed link modal');
                    }
                });
            }

            if (dom.linkModal) {
                dom.linkModal.addEventListener('click', (e) => {
                    if (e.target === dom.linkModal) {
                        dom.linkModal.classList.add('hidden');
                        console.log('Closed link modal via overlay click');
                    }
                });
            }

            if (dom.linkForm) {
                dom.linkForm.addEventListener('submit', (e) => {
                    e.preventDefault();
                    const name = dom.linkNameInput.value.trim();
                    const url = dom.linkUrlInput.value.trim();
                    if (name && url) {
                        addLink(name, url);
                        dom.linkForm.reset();
                        dom.linkModal.classList.add('hidden');
                    }
                });
            }

            if (dom.linksGrid) {
                dom.linksGrid.addEventListener('click', (e) => {
                    if (e.target.classList.contains('delete-link-btn')) {
                        e.preventDefault();
                        const index = parseInt(e.target.dataset.index);
                        deleteLink(index);
                    }
                });
            }

            // Weather
            if (dom.weatherMain) {
                dom.weatherMain.addEventListener('click', () => {
                    if (dom.weatherForecast) {
                        dom.weatherForecast.classList.toggle('hidden');
                        console.log('Toggled weather forecast visibility');
                    }
                });
            }

            if (dom.weatherEditBtn) {
                dom.weatherEditBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    if (dom.locationForm) {
                        dom.locationForm.classList.toggle('hidden');
                        dom.locationInput.focus();
                        console.log('Toggled location form visibility');
                    }
                });
            }

            if (dom.locationDisplay) {
                dom.locationDisplay.addEventListener('click', () => {
                    if (dom.weatherForecast) {
                        dom.weatherForecast.classList.toggle('hidden');
                        console.log('Toggled weather forecast via location display');
                    }
                });
            }

            if (dom.locationInput) {
                const debouncedCitySearch = debounce((city) => getCoordsForCity(city, false), 300);
                dom.locationInput.addEventListener('input', () => {
                    const query = dom.locationInput.value.trim();
                    if (query.length > 2) {
                        debouncedCitySearch(query);
                    } else {
                        if (dom.locationResults) dom.locationResults.classList.add('hidden');
                    }
                });
            }

            if (dom.locationForm) {
                dom.locationForm.addEventListener('submit', (e) => {
                    e.preventDefault();
                    const city = dom.locationInput.value.trim();
                    if (city) {
                        getCoordsForCity(city, true);
                        dom.locationInput.value = '';
                        if (dom.locationResults) dom.locationResults.classList.add('hidden');
                        if (dom.locationForm) dom.locationForm.classList.add('hidden');
                    }
                });
            }

            // Settings
            if (dom.settingsBtn) {
                dom.settingsBtn.addEventListener('click', () => {
                    if (dom.settingsModal) {
                        dom.settingsModal.classList.remove('hidden');
                        console.log('Opened settings modal');
                    }
                });
            }

            if (dom.settingsCloseBtn) {
                dom.settingsCloseBtn.addEventListener('click', () => {
                    if (dom.settingsModal) {
                        dom.settingsModal.classList.add('hidden');
                        console.log('Closed settings modal');
                    }
                });
            }

            if (dom.settingsModal) {
                dom.settingsModal.addEventListener('click', (e) => {
                    if (e.target === dom.settingsModal) {
                        dom.settingsModal.classList.add('hidden');
                        console.log('Closed settings modal via overlay click');
                    }
                });
            }

            if (dom.settingsToggles) {
                dom.settingsToggles.addEventListener('change', handleVisibilityToggle);
            }

            // Image Controls
            if (dom.imageControlBtn) {
                dom.imageControlBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    console.log('Image control button clicked');
                    if (dom.imageControlsPopup) {
                        const popup = dom.imageControlsPopup;
                        popup.classList.toggle('hidden');
                        if (!popup.classList.contains('hidden')) {
                            popup.style.display = 'flex';
                            popup.style.opacity = '1';
                            popup.querySelectorAll('button').forEach(btn => {
                                btn.style.pointerEvents = 'auto';
                                btn.style.opacity = '1';
                            });
                        } else {
                            popup.style.display = 'none';
                            popup.style.opacity = '0';
                        }
                    } else {
                        console.error('Cannot toggle popup: .image-controls-popup not found');
                    }
                });
            } else {
                console.error('Cannot attach event listener: .image-control-btn not found');
            }

            if (dom.pinImageBtn) {
                dom.pinImageBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    console.log('Pin button clicked');
                    const currentImage = localStorage.getItem('currentBackgroundImage');
                    if (currentImage && currentImage.startsWith('http')) {
                        localStorage.setItem('pinnedImageUrl', currentImage);
                        if (dom.body) {
                            dom.body.style.backgroundImage = `url(${currentImage})`;
                            console.log('Pinned image:', currentImage);
                        }
                        updateImageControlsUI();
                        if (dom.imageControlsPopup) {
                            dom.imageControlsPopup.classList.add('hidden');
                        }
                    } else {
                        console.warn('No valid current image, using fallback');
                        const fallbackUrl = 'https://images.unsplash.com/photo-1514565131-fce0801e5785';
                        localStorage.setItem('pinnedImageUrl', fallbackUrl);
                        localStorage.setItem('currentBackgroundImage', fallbackUrl);
                        if (dom.body) {
                            dom.body.style.backgroundImage = `url(${fallbackUrl})`;
                            console.log('Pinned fallback image:', fallbackUrl);
                        }
                        updateImageControlsUI();
                        if (dom.imageControlsPopup) {
                            dom.imageControlsPopup.classList.add('hidden');
                        }
                    }
                });
            }

            if (dom.refreshImageBtn) {
                dom.refreshImageBtn.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    console.log('Refresh button clicked');
                    localStorage.removeItem('pinnedImageUrl');
                    localStorage.removeItem('imagePool');
                    localStorage.removeItem('currentBackgroundImage');
                    console.log('Cleared pinnedImageUrl, imagePool, and currentBackgroundImage');
                    await refillImagePool();
                    await setBackground('refreshImageBtn');
                    updateImageControlsUI();
                    if (dom.imageControlsPopup) {
                        dom.imageControlsPopup.classList.add('hidden');
                    }
                });
            }

            if (dom.resumeImageBtn) {
                dom.resumeImageBtn.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    console.log('Resume button clicked');
                    localStorage.removeItem('pinnedImageUrl');
                    localStorage.removeItem('imagePool');
                    localStorage.removeItem('currentBackgroundImage');
                    console.log('Cleared pinnedImageUrl, imagePool, and currentBackgroundImage');
                    await refillImagePool();
                    await setBackground('resumeImageBtn');
                    updateImageControlsUI();
                    if (dom.imageControlsPopup) {
                        dom.imageControlsPopup.classList.add('hidden');
                    }
                });
            }

            // Blur Slider
            if (dom.blurSlider) {
                dom.blurSlider.addEventListener('input', (e) => {
                    const blurValue = e.target.value;
                    if (dom.backgroundOverlay) {
                        dom.backgroundOverlay.style.setProperty('--background-blur', `${blurValue}px`);
                        dom.backgroundOverlay.style.backdropFilter = `blur(${blurValue}px)`;
                        dom.backgroundOverlay.style.webkitBackdropFilter = `blur(${blurValue}px)`;
                        localStorage.setItem('backgroundBlur', blurValue);
                        console.log(`Set blur value: ${blurValue}px`);
                    } else {
                        console.error('Cannot apply blur: backgroundOverlay missing');
                    }
                });
            } else {
                console.error('Cannot attach blur slider event listener: blurSlider not found');
            }

            // Global click handler for closing popups
            document.addEventListener('click', (e) => {
                if (dom.locationResults && !dom.locationResults.contains(e.target) && !dom.locationInput.contains(e.target)) {
                    dom.locationResults.classList.add('hidden');
                }
                if (dom.imageControlsPopup && !dom.imageControlsPopup.classList.contains('hidden') && !dom.imageControlsPopup.contains(e.target) && !dom.imageControlBtn.contains(e.target)) {
                    dom.imageControlsPopup.classList.add('hidden');
                    console.log('Closed image controls popup');
                }
            });

            // Window Focus
            window.addEventListener('focus', () => {
                loadStateFromStorage();
                updateClock();
                console.log('Window focused, refreshed state');
            });

        } catch (error) {
            console.error('Failed to setup event listeners:', error);
        }
    }

    // Initialization
    async function init() {
        try {
            console.log('Initializing extension...');
            if (!dom.body) throw new Error('Body element not found');
            loadStateFromStorage();
            applyVisibilitySettings();
            updateClock();
            setGreeting();
            setInterval(updateClock, 1000);
            setInterval(setGreeting, 60 * 60 * 1000);
            setChillMessage();
            loadYouTubeIframeAPI();
            setupEventListeners();
            console.log('Initializing background...');
            await prepareNextBackground(true, 'init');
            updateImageControlsUI();
            await Promise.all([
                setQuote(),
                handleLocation()
            ]);
            console.log('Extension initialized successfully', {
                pinnedImageUrl: localStorage.getItem('pinnedImageUrl'),
                currentBackgroundImage: localStorage.getItem('currentBackgroundImage'),
                imagePoolSize: (JSON.parse(localStorage.getItem('imagePool')) || []).length
            });
        } catch (error) {
            console.error('Initialization failed:', error);
            if (dom.body) {
                const fallbackUrl = 'https://images.unsplash.com/photo-1514565131-fce0801e5785';
                dom.body.style.backgroundImage = `url(${fallbackUrl})`;
                localStorage.setItem('currentBackgroundImage', fallbackUrl);
                console.log(`Set fallback image due to init failure: ${fallbackUrl}`);
            }
            if (dom.chillMessage) dom.chillMessage.textContent = 'Error loading extension. Try refreshing.';
        }
    }

    init();
});

window.clearLocalStorage = function() {
    localStorage.clear();
    console.log('Cleared localStorage');
};